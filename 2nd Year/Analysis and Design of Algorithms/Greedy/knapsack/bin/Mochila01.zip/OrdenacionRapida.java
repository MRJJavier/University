import java.util.ArrayList;

////////////////////////////////////////////////////////////////////////////////////////////
// ALUMNO: José Javier Morente Risco
// GRUPO: 2ºC
////////////////////////////////////////////////////////////////////////////////////////////

public class OrdenacionRapida  {
  
	public static <T extends Comparable<? super T>> void ordenar(ArrayList<Item> items) {
	    ordRapidaRec(items, 0, items.size()-1);
	}

	// Debe ordenar ascendentemente los primeros @n elementos del vector @v con 
	// una implementaci�n recursiva del m�todo de ordenaci�n r�pida.	
	public static <T extends Comparable<? super T>> void ordRapidaRec(ArrayList<Item> items, int izq, int der) {
	    // A completar por el alumno
		if(izq < der) {
			int s=partir(items,items.get(izq),izq,der);
			ordRapidaRec(items,izq,s);
			ordRapidaRec(items,s+1,der);
		}	
	}
	
   public static <T extends Comparable<? super T>> int partir(ArrayList<Item> items, Item item, int izq, int der) {
	    // A completar por el alumno
	   int i=izq-1;
	   int j=der+1;
	   while(i<j) {
		   do {
			   j--;
		   }while(items.get(j).compareTo(item)>0);
		   do {
			   i++;
		   }while(items.get(i).compareTo(item)<0);
		   if(i<j) {
			   Item aux=items.get(i);
			   items.set(i,items.get(j));
			   items.set(j,aux);
			   
		   }
	   }
	    return j;    	
   }

    
}
