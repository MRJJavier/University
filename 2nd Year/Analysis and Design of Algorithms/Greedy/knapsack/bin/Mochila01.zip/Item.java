
public class Item implements Comparable<Item>{
	int index;
	float peso;
	float valor;
	float unidades;
	float densidad;
	
	public Item(int index, float peso, float valor, float unidades) {
		this.index = index;
		this.peso = peso;
		this.valor = valor;
		this.unidades = unidades;
		this.densidad = this.valor/this.peso;
	}
	
	
	@Override
	public int compareTo (Item otro){
		if (densidad==otro.densidad) return 0;
		else if (densidad<otro.densidad) return -1;
		return 1;  
	}
	
}
	
