package relaciondyv;

public class ejercicio2 {

}
